<?php
/**
 * Loop
 *
 * @package magplus
 * @since 1.0
 */
?>
<div class="col-md-12">
  <h4><?php echo magplus_get_opt('translation-no-post-found'); ?></h4>
</div>
